# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end

Refile.secret_key = 'abf74be4011fe078a731d783a2e0fb2d4c4368237ba05f50ce15fe8c31279149e502c86bdfccbcde64456c6fb83c72f4d2c7f895ab34dbe4f9af3598b18ddd47'

class HomesController < ApplicationController
  def about
  end

  def top
  end
end
